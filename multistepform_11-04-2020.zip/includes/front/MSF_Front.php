<?php
/**
 * MSF Front
 *
 * Manage Actions
 *
 * @since 1.0.0
 */
class MSF_Front {

    /**
     * Initial class
     *
     * @since 1.0.0
     */
    public function __construct() {
        include_once MSF_INCLUDES_FRONT.'MSF_style_scripts.php';
        include_once MSF_INCLUDES_FRONT.'MSF_shortcodes.php';
    }

}
