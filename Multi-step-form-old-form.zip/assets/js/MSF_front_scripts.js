$ = jQuery;
jQuery(document).ready(function ($) {
    var current = 1;
    widget = $(".step");
    btnnext = $(".next");
    btnback = $(".back");
    btnsubmit = $(".submit");
    // Init buttons and UI
    widget.not(':eq(0)').hide();
    hideButtons(current);
    setProgress(current);

    // Next button click action
    btnnext.click(function (e) {
        if (current < widget.length) {
            console.log("inner");
            e.preventDefault();
            widget.show();
            widget.not(':eq(' + (current++) + ')').hide();
            setProgress(current);
            //alert("I was called from btnNext");
        }
        hideButtons(current);
    });

    // Back button click action
    btnback.click(function () {
        if (current > 1) {
            current = current - 2;
            btnnext.trigger('click');
        }
        hideButtons(current);
    });
}, jQuery);

// Change progress bar action
setProgress = function (currstep) {
    var percent = parseFloat(100 / widget.length) * currstep;
    percent = percent.toFixed();
    $(".progress-bar")
        .css("width", percent + "%")
        .html(percent + "%");
};

// Hide buttons according to the current step
hideButtons = function (current) {
    var limit = parseInt(widget.length);

    $(".action").hide();

    if (current < limit) btnnext.show();
    if (current > 1) btnback.show();
    if (current == limit) {
        btnnext.hide();
        btnsubmit.show();
    }
};

function transform(n) {
    if (n > 299) {
        return "> 300";
    }

    return n;
}

$range = $(".js-range-slider");
$square_meters = $(".square-meters");
$range.ionRangeSlider({
    skin: "square",
    type: "single",
    min: 0,
    max: 300,
    from: 150,
    grid: true,
    postfix: "m<sup>2</sup>",
    prettify: function (n) {
        return transform(n);
    },
    onChange: function (data) {
        $square_meters.prop("value", data.from);
    }
});
instance = $range.data("ionRangeSlider");


jQuery.validator.addMethod("noSpace", function (value, element) {
    return value.trim() != "";
}, "Please fill the box");
form=jQuery("#submission_form");
form.validate({
    ignore: 'input[type=hidden]',
    errorClass: 'validation-error-label',
    highlight: function (element, errorClass) {
        $(element).removeClass(errorClass);
    },
    unhighlight: function (element, errorClass) {
        $(element).removeClass(errorClass);
    },
    rules: {
        "household": {
            required: true,
        },
        "disposed": {
            required: true,
        },
        "Vorname": {
            required: true,
            noSpace: true,
        },
        "Nachname": {
            required: true,
            noSpace: true,
        },
        "Email": {
            required: true,
            noSpace: true,
        },

        "Telefon": {
            required: true,
            noSpace: true,
        },
        "PLZ": {
            required: true,
            noSpace: true,
        },
        "privacy-val": {
            required: true,
        },
    }
});

form.children("div").steps({
    headerTag: "h3",
    bodyTag: "section",
    transitionEffect: "slideLeft",
    onStepChanging: function (event, currentIndex, newIndex)
    {
        form.validate().settings.ignore = ":disabled,:hidden";
        return form.valid();
    },
    onFinishing: function (event, currentIndex)
    {
        form.validate().settings.ignore = ":disabled";
        return form.valid();
    },
    onFinished: function (event, currentIndex)
    {
        alert("Submitted!");
    }
});