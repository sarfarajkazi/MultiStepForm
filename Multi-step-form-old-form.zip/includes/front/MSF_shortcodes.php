<?php
/**
 * MSF Load front styles and scripts
 *
 * Manage Short codes
 *
 * @since 1.0.0
 */
class MSF_shortcodes
{
    /**
     * Initial class
     *
     * @since 1.0.0
     */
    public function __construct() {
       add_shortcode('display_form',array($this,'display_form_callback'));
    }
    function display_form_callback(){
        ob_start();

        include_once 'templates/form_layout.php';
        wp_enqueue_style("range-slider");
        wp_enqueue_script('rangeSlider');
        wp_enqueue_script('custom-js-validation');
        wp_enqueue_script('additional-methods');
        wp_enqueue_script('bootstrap-min-js');
        wp_enqueue_script('front_script');
        $html=ob_get_contents();
        ob_clean();
        return $html;
    }
}
return new MSF_shortcodes();